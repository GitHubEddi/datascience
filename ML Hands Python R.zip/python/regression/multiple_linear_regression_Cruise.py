#Multiple Linear Regression - Cruise

#Import the Libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

#Import the dataset
dataset = pd.read_csv('cruise_ship_info.csv')
#Independent variables - Cruise_line to passenger_density
X = dataset.iloc[:, 1:8].values
#Dependent variables :- crew
y = dataset.iloc[:, 8].values

dataset.info()

#Encoding of Categorical data :-State
#Encoding of Independent variables
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
labelencoder_X = LabelEncoder()
X[:, 0] = labelencoder_X.fit_transform(X[:, 0])
onehotencoder = OneHotEncoder(categorical_features = [0])
X = onehotencoder.fit_transform(X).toarray()

#Avoiding the Dummy Variable Trap
X = X[:, 1:]

#Splitting the dataset into the Training Set and Testing Set
from sklearn.model_selection import train_test_split 
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)

#Fitting Multiple Linear Regression into Training Set
from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(X_train, y_train)

#Predicting the Test Set results
y_pred = regressor.predict(X_test)

#Very strong correlation between crew and passengers
dataset['crew'].corr(dataset['passengers'])

# Negative correlation
dataset['crew'].corr(dataset['Age'])

# Negative correlation
dataset['crew'].corr(dataset['cabins'])


passengers = dataset.iloc[:, 4].values
crew = dataset.iloc[:, 8].values

#Visualising the Training set results
plt.scatter(X_train, y_train, color='red')
plt.plot(X_train, regressor.predict(X_train), color='blue')
plt.title('Salary vs Experience (Training Set)')
plt.xlabel('Years of Experience')
plt.ylabel('Salary')
plt.show()