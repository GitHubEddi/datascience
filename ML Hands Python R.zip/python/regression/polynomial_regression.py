#Polynomial Regression

#Import the Libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

#Import the dataset
dataset = pd.read_csv('Position_Salaries.csv')
#Add Independent variables (Level X)
# 1st : - represents all the rows
# 2nd : - represents all the columes (we are taking lost column -1)
X = dataset.iloc[:, 1:2].values
# Add dependent variables (Salary) 
# Python index start with 0. So, Colum purchased is 2
y = dataset.iloc[:, 2].values

#Fitting Linear Regression to the dataset
from sklearn.linear_model import LinearRegression
lin_reg = LinearRegression()
lin_reg.fit(X, y)

#Fitting Polynomial Regression to the dataset
from sklearn.preprocessing import PolynomialFeatures
poly_reg = PolynomialFeatures(degree = 4) #default value
X_poly = poly_reg.fit_transform(X)
lin_reg2 = LinearRegression()
lin_reg2.fit(X_poly, y)

#Visualizing Linear Regression results
plt.scatter(X, y, color='red') # Real X - grade & y - salary
plt.plot(X, lin_reg.predict(X), color='blue')
plt.title('Truth or Bluff (Linear Regression)')
plt.xlabel('Position Level')
plt.ylabel('Salary')
plt.show()

#Visualizing Polynomial Linear Regression results
X_grid = np.arange(min(X), max(X), 0.1)
X_grid = X_grid.reshape((len(X_grid), 1))
plt.scatter(X, y, color='red') # Real X - grade & y - salary
plt.plot(X_grid, lin_reg2.predict(poly_reg.fit_transform(X_grid)), color='blue')
plt.title('Truth or Bluff (Polynomial Regression)')
plt.xlabel('Position Level')
plt.ylabel('Salary')
plt.show()

#Predicting a new result with linear Regression
#return predicted 6.5 level
y_predict = np.array([[6.5]])  #Input to .predict must be 2-dimensional
lin_reg.predict(y_predict)

#Predicting a new result with Polynomial linear Regression
poly_predict = np.array([[6.5]])  #Input to .predict must be 2-dimensional
lin_reg2.predict(poly_reg.fit_transform(poly_predict))
