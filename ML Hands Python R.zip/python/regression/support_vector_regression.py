# Support Vector Regression

#Import the Libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

#Import the dataset
dataset = pd.read_csv('Position_Salaries.csv')
#Add Independent variables (Level X)
# 1st : - represents all the rows
# 2nd : - represents all the columes (we are taking lost column -1)
X = dataset.iloc[:, 1:2].values
# Add dependent variables (Salary) 
# Python index start with 0. So, Colum Salary is 2
y = dataset.iloc[:, 2].values

#Feature sacling
from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
sc_y = StandardScaler()
X = sc_X.fit_transform(X)
y = np.squeeze(sc_y.fit_transform(y.reshape(-1, 1)))


#Fitting SVR to the dataset
from sklearn.svm import SVR
regressor = SVR(kernel='rbf')
regressor.fit(X, y)

#Predicting a new result #return predicted 6.5 level
#Input to predict must be 2-dimensional and feature scaling as well
#inverse transfer object for real value
y_pred = sc_y.inverse_transform(regressor.predict(sc_X.transform(np.array([[6.5]])))) 


#Visualizing SVR results
plt.scatter(X, y, color='red') # Real X - grade & y - salary
plt.plot(X, regressor.predict(X), color='blue')
plt.title('Truth or Bluff (SVR)')
plt.xlabel('Position Level')
plt.ylabel('Salary')
plt.show()


#Visualizing SVR results for higher resolution
X_grid = np.arange(min(X), max(X), 0.1)
X_grid = X_grid.reshape((len(X_grid), 1))
plt.scatter(X, y, color='red') # Real X - grade & y - salary
plt.plot(X_grid, regressor.predict(X_grid), color='blue')
plt.title('Truth or Bluff (SVR Regression)')
plt.xlabel('Position Level')
plt.ylabel('Salary')
plt.show()

