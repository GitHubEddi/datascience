#Random Forest Regression

#Import the Libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

#Import the dataset
dataset = pd.read_csv('Position_Salaries.csv')
#Add Independent variables (Level X)
# 1st : - represents all the rows
# 2nd : - represents all the columes (we are taking column 1 - python starts with zero index)
X = dataset.iloc[:, 1:2].values
# Add dependent variables (Salary) 
# Python index start with 0. So, Colum Salary is 2
y = dataset.iloc[:, 2].values

#Fitting Random Forest Regression to the dataset
from sklearn.ensemble import RandomForestRegressor
regressor = RandomForestRegressor(n_estimators = 300, random_state = 0)
regressor.fit(X, y)


#Visualizing the Regression results (Higher resolution and smoother curve)
X_grid = np.arange(min(X), max(X), 0.01)
X_grid = X_grid.reshape((len(X_grid), 1))
plt.scatter(X, y, color='red') # Real X - grade & y - salary
plt.plot(X_grid, regressor.predict(X_grid), color='blue')
plt.title('Truth or Bluff (Polynomial Regression)')
plt.xlabel('Position Level')
plt.ylabel('Salary')
plt.show()

#Predicting a new result with Random Forest Regression
#return predicted 6.5 level
y_predict = np.array([[6.5]])  #Input to .predict must be 2-dimensional
y_pred = regressor.predict(y_predict)