#Multiple Linear Regression

#Import the Libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

#Import the dataset
dataset = pd.read_csv('50_Startups.csv')
#Independent variables - R&D Spend, Administration, Marketing Spend and State
X = dataset.iloc[:, :-1].values
#Dependent variables :- Profit
y = dataset.iloc[:, 4].values

#Encoding of Categorical data :-State
#Encoding of Independent variables
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
labelencoder_X = LabelEncoder()
X[:, 3] = labelencoder_X.fit_transform(X[:, 3])
onehotencoder = OneHotEncoder(categorical_features = [3])
X = onehotencoder.fit_transform(X).toarray()

#Avoiding the Dummy Variable Trap
X = X[:, 1:]

#Splitting the dataset into the Training Set and Testing Set
from sklearn.model_selection import train_test_split 
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)

#Fitting Multiple Linear Regression into Training Set
from sklearn.linear_model import LinearRegression
regressor = LinearRegression()
regressor.fit(X_train, y_train)

#Predicting the Test Set results
y_pred = regressor.predict(X_test)

# Building the Optimal model using Backward Elimination
import statsmodels.formula.api as sm
X = np.append(arr = np.ones((50, 1)).astype(int), values = X, axis=1)
#X_opt contains the variables high impact to the dependent varaibles
X_opt = X[:, [0,1,2,3,4,5]]
#Step 2 --> Fit the full model with all possible predictors
regress_OLS = sm.OLS(endog = y, exog = X_opt).fit()
#Step 3 --> Consider the predictor with the highest P-value. if P > SL, goto STEP 4, otherwise goto FIN
regress_OLS.summary()

# Step 4 --> Remove the Predictor X2  - Dummy varaible
X_opt = X[:, [0,1,3,4,5]]
regress_OLS = sm.OLS(endog = y, exog = X_opt).fit()
regress_OLS.summary()

# Step 4 --> Remove the Predictor X1 - Dummay variable
X_opt = X[:, [0,3,4,5]]
regress_OLS = sm.OLS(endog = y, exog = X_opt).fit()
regress_OLS.summary()

# Step 4 --> Remove the Predictor X1 - Admin variable
X_opt = X[:, [0,3,5]]
regress_OLS = sm.OLS(endog = y, exog = X_opt).fit()
regress_OLS.summary()

# Step 4 --> Remove the Predictor X2 - Marketing variable
X_opt = X[:, [0,3]]
regress_OLS = sm.OLS(endog = y, exog = X_opt).fit()
regress_OLS.summary()

import statsmodels.formula.api as sm
def backwardElimination(x, sl):
    numVars = len(x[0])
    for i in range(0, numVars):
        regressor_OLS = sm.OLS(y, x).fit()
        maxVar = max(regressor_OLS.pvalues).astype(float)
        if maxVar > sl:
            for j in range(0, numVars - i):
                if (regressor_OLS.pvalues[j].astype(float) == maxVar):
                    x = np.delete(x, j, 1)
    regressor_OLS.summary()
    print(regressor_OLS.summary())
    return x
 
SL = 0.05
X_opt = X[:, [0, 1, 2, 3, 4, 5]]
X_Modeled = backwardElimination(X_opt, SL)
