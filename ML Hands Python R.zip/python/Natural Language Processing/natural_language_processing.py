# Natural Language Processing

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Importing the dataset
dataset = pd.read_csv('Restaurant_Reviews.tsv', delimiter ='\t', quoting = 3)

#Cleaning the texts
import re # package is used for cleaning the text - re: Regular Expressions
import nltk # The Natural Language Toolkit
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem.porter import PorterStemmer # for Stemming

corpus = [] #Collection of text
for i in range(0, 1000):
    # 1st Parameter --> will keep only a-z and A-Z
    # 2nd Parameter --> will replace the removed characters with space ' '
    review = re.sub('[^a-zA-Z]', ' ', dataset['Review'][i]) 
    # 'Wow... Loved this place.' --> 'Wow    Loved this place '
    
    # Convert Captial letters into lower case
    review = review.lower()
    #'Wow    Loved this place ' --> 'wow    loved this place '
    
    # Splitting the word
    review = review.split()
    # 'wow    loved this place ' --> ['wow', 'loved', 'this', 'place']
    ps = PorterStemmer() # create Object for Stemming
    review = [ps.stem(word) for word in review if not word in set(stopwords.words('english'))]
    # ['wow', 'loved', 'this', 'place'] --> ['wow', 'love', 'place']
    
    review = ' '.join(review)
    # ['wow', 'love', 'place'] --> 'wow love place'
    corpus.append(review)
    
# Creating the Bag of Words Model
from sklearn.feature_extraction.text import CountVectorizer
cv = CountVectorizer(max_features = 1500)
X = cv.fit_transform(corpus).toarray()
# Dependent variable
y = dataset.iloc[:, 1].values

#let's use Naive Bayes classification
# Splitting the dataset into the Training set and Test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.20, random_state = 0)

# Fitting the Naive Bayes Classifier to the Training Set
from sklearn.naive_bayes import GaussianNB
classifier = GaussianNB()
classifier.fit(X_train, y_train)

# Predicting the Test set results
y_pred = classifier.predict(X_test)

# Making the Confusion Matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)

accuracy_prediction = (55 + 91) / 200 #200 test set

