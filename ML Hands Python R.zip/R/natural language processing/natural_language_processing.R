#Natural Language Processing

#Importing the Dataset
dataset_Original = read.delim('Restaurant_Reviews.tsv', quote = '', stringsAsFactors = FALSE)

#Cleaning the text
#install.packages('tm')
library(tm)
corpus = VCorpus(VectorSource(dataset_Original$Review))
#Convert all Captial letters into lower cases
corpus = tm_map(corpus, content_transformer(tolower))
# Remove Numbers
corpus = tm_map(corpus, removeNumbers)
# Remove Punctuation
corpus = tm_map(corpus, removePunctuation)
# remove non-significant words
#install.packages('SnowballC')
library(SnowballC)
corpus = tm_map(corpus, removeWords, stopwords())
# Stemming - Get the root of the word
corpus = tm_map(corpus, stemDocument)
# Remove the extra space
corpus = tm_map(corpus, stripWhitespace)

# Creating the Bag of Words Model
dtm = DocumentTermMatrix(corpus)
# remove non-frequent words - 99% of words
dtm = removeSparseTerms(dtm, 0.999)

# Using Random forest classifications model
# Convert sparse matrix to dataset
dataset = as.data.frame(as.matrix(dtm))
dataset$Liked = dataset_Original$Liked # add dependent variable

# Encoding the target feature as factor
dataset$Liked = factor(dataset$Liked, levels = c(0, 1))

# Splitting the dataset into the Training set and Test set
# install.packages('caTools')
library(caTools)
set.seed(123)
split = sample.split(dataset$Liked, SplitRatio = 0.8)
training_set = subset(dataset, split == TRUE)
test_set = subset(dataset, split == FALSE)

# Fitting Random Forest Classification to the Training set
# install.packages('randomForest')
library(randomForest)
classifier = randomForest(x = training_set[-692],
                          y = training_set$Liked,
                          ntree = 10)

# Predicting the Test set results
y_pred = predict(classifier, newdata = test_set[-692])

# Making the Confusion Matrix
cm = table(test_set[, 692], y_pred)

#Accuracy of prediction
accuracy = (82 + 77) /200
