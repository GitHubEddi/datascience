# Apriori 

#Data preprocessing
dataset = read.csv('Market_Basket_Optimisation.csv', header = FALSE )

# Build sparse matrix
#install.packages('arules')
library(arules)
dataset = read.transactions('Market_Basket_Optimisation.csv', 
                            sep = ',', # CSV file is created by separated by comma
                            rm.duplicates = TRUE) # remvoe if any duplicates
summary(dataset)
itemFrequencyPlot(dataset, topN = 10)

# Training Apriori on the dataset

#SUPPORT
#Let's take product purchased 3 times a day in week ??? 3 * 7 = 21
#Total no. transactions ??? 7500
#21 / 7500 = 0.0028 will be the support.
#DEFAULT CONFIDENCE VALUE 0.8
rules = apriori(data = dataset, parameter = list(support = 0.004, confidence = 0.2 ))

# Visualizing the results
inspect(sort(rules, by = 'lift') [1:10]) # sort by 1st 10 highest rules